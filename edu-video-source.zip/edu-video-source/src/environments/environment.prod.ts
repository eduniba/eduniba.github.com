export const environment = {
  production: true,
  assetsAddress:"/edu-video/assets/"
};
