import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { MainToolbarComponent } from './main-toolbar/main-toolbar.component';
import { ReusablesModule } from './reusables/reusables.module';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomepageComponent } from './homepage/homepage.component';
import { YoutubePlayerComponent } from './youtube-player/youtube-player.component';

@NgModule({
  declarations: [
    AppComponent,
    MainToolbarComponent,
    SidebarComponent,
    HomepageComponent,
    YoutubePlayerComponent,
  ],
  imports: [
    BrowserModule,
    ReusablesModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
