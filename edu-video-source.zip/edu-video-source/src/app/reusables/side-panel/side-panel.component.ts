import { Component, HostListener, Input, OnInit } from '@angular/core'
import { messages } from "src/app/models/variables.enum"
import { BroadcastService } from 'src/app/services/broadcast.service'
import { ControlsService } from 'src/app/services/controls.service'

@Component({
  selector: 'app-side-panel',
  templateUrl: './side-panel.component.html',
  styleUrls: ['./side-panel.component.scss']
})
export class SidePanelComponent implements OnInit {

  @Input() id:string=""
  @Input() side:string="left"
  @Input() showing:boolean=false
  @HostListener("click",["$event"]) clickClose(event:any){
    if(event.target.className.includes("wrapper")) this.close()
  }

  constructor(
    private bcServ:BroadcastService,
    private controlsServ:ControlsService) { }

  ngOnInit(): void {
    this.bcServ.getEventBroadcaster().subscribe(
      (message)=>{
        switch(message.name){
          case messages.toggleSidePanel:
            if(message.detail.id==this.id) this.toggle()
            else if(this.showing) this.close()
            break
          case messages.closeSidePanel:
            if(message.detail.id==this.id) this.close()
            break
          case messages.openSidePanel:
            if(message.detail.id==this.id) this.open()
            break
          default:break
        }
      }
    )
    this.controlsServ.getGestureUpdate().subscribe(
      (message)=>{
        if(message.gestures.indexOf("swipe_"+this.side)!=-1&&this.showing) this.toggle()
      }
    )
  }

  toggle(){
    this.showing=!this.showing
  }
  close(){
    this.showing=false
  }
  open(){
    this.showing=true
  }

}
