import { Component, OnInit } from '@angular/core'
import { messages } from 'src/app/models/variables.enum'
import { BroadcastService } from 'src/app/services/broadcast.service'
import { ControlsService } from 'src/app/services/controls.service'

@Component({
  selector: 'app-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  showing:boolean=false
  type:string="confirm"//alert,confirm,text
  title:string=""
  message:string=""

  passOn:string|number=""

  constructor(
    private bcServ:BroadcastService,
    private controlsServ:ControlsService) { }

  ngOnInit(): void {
    this.bcServ.getEventBroadcaster().subscribe(
      message=>{
        switch(message.name){
          case messages.openDialog:
            if(message.detail.type!=""){
              setTimeout(()=>{
                this.type=message.detail.type
                this.title=message.detail.title
                this.message=message.detail.message
                if(message.detail.type=="confirm"&&message.detail.passOn!="") this.passOn=message.detail.passOn
                this.open()
              })
            }
            break
          case messages.closeDialog:
            this.close()
            break
          default:break
        }
      }
    )

    this.controlsServ.getControlsUpdate().subscribe(
      message=>{
        if(message.case=="up"&&this.showing&&this.type=="alert") this.close()
      }
    )
  }

  toggle(){this.showing=!this.showing}
  close(){this.showing=false}
  open(){this.showing=true}

  confirm(value:boolean){
    if(value){
      this.bcServ.dispatch(messages.confirmResponse,{value:true,passOn:this.passOn})
    }else{
      this.bcServ.dispatch(messages.confirmResponse,{value:false,passOn:this.passOn})
    }
    this.passOn=""
    this.close()
  }

  clickWrapper(){
    if(this.type==="alert"&&this.showing) this.close()
  }
}
