import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { SquareButtonComponent } from './square-button/square-button.component'
import { SidePanelComponent } from './side-panel/side-panel.component'
import { DialogComponent } from './dialog/dialog.component'



@NgModule({
  declarations: [
    SquareButtonComponent,
    SidePanelComponent,
    DialogComponent,
  ],
  imports: [
    CommonModule,
  ],
  exports:[
    SquareButtonComponent,
    SidePanelComponent,
    DialogComponent,
  ]
})
export class ReusablesModule { }
