import { Component, Input, OnInit } from '@angular/core'
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-square-button',
  templateUrl: './square-button.component.html',
  styleUrls: ['./square-button.component.scss']
})
export class SquareButtonComponent implements OnInit {

  constructor() { }

  assetsAddress:string=environment.assetsAddress+"icons/"

  @Input() icon:string="menu"
  @Input() extension:string="svg"

  @Input() side:string[]=["2em","2em"]

  @Input() backgroundColor:string="var(--square-button-background-color)"

  _color:string="var(--square-button-color)"
  @Input() set color(value:string){
    if(value.startsWith("var")){
      let variable=value.substring(4,value.length-1)
      this._color=getComputedStyle(document.body).getPropertyValue(variable)
    }else this._color=value
  }
  @Input() borderColor:string="var(--square-button-border-color)"
  @Input() shadowColor:boolean=true


  ngOnInit(): void {
  }
}
