import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BroadcastService {
  private eventBrocker = new Subject<any>();

  getEventBroadcaster(){
    return this.eventBrocker.asObservable()
  }
  dispatch(eventName: any,detail:any={}): void {
    this.eventBrocker.next({name:eventName,detail});
  }
}
