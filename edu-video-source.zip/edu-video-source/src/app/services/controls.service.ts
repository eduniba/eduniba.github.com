import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ControlsService {

  constructor() { }

  private isPointerDown:boolean=false
  private startPointer:number[]=[0,0]
  private lastPointer:number[]=[0,0]
  private currentPointer:number[]=[0,0]
  private startTime:number=0

  controlsUpdate:Subject<any>=new Subject<any>()
  gestureUpdate:Subject<any>=new Subject<any>()

  private timeTolerance=250
  private gestureTolerances=[100,100]

  setup(){
    window.addEventListener("wheel",(ev)=>this.mouseWheel(ev))
    // window.addEventListener("pointerdown",(ev)=>this.pointerDown(ev))
    // window.addEventListener("pointermove",(ev)=>this.pointerMove(ev))
    // window.addEventListener("pointerleave",(ev)=>this.pointerUp(ev))
    // window.addEventListener("pointercancel",(ev)=>this.pointerUp(ev))
    // window.addEventListener("pointerup",(ev)=>this.pointerUp(ev))

    window.addEventListener("mousedown",(ev)=>this.pointerDown(ev))
    window.addEventListener("mousemove",(ev)=>this.pointerMove(ev))
    window.addEventListener("mouseleave",(ev)=>this.pointerUp(ev))
    window.addEventListener("mousecancel",(ev)=>this.pointerUp(ev))
    window.addEventListener("mouseup",(ev)=>this.pointerUp(ev))

    window.addEventListener("touchstart",(ev)=>this.touchDown(ev))
    window.addEventListener("touchmove",(ev)=>this.touchMove(ev))
    window.addEventListener("touchend",(ev)=>this.touchUp(ev))
    window.addEventListener("touchcancel",(ev)=>this.touchUp(ev))
  }


  mouseWheel(event:any){
    this.controlsUpdate.next({
      case:"wheel",
      isPpointerDown:this.isPointerDown,
      delta:[event.deltaX,event.deltaY],
      target:event.target,
      event
    })
  }

  touchDown(event:any){
    event.screenX=event.touches[0].screenX
    event.screenY=event.touches[0].screenY
    this.pointerDown(event)
  }
  pointerDown(event:any){
    this.isPointerDown=true
    this.startPointer=[event.screenX,event.screenY]
    this.lastPointer=[event.screenX,event.screenY]
    this.currentPointer=[event.screenX,event.screenY]
    this.startTime=Date.now()
    this.controlsUpdate.next({
      case:"down",
      start:[...this.startPointer],
      startTime:this.startTime,
      target:event.target,
      event
    })
  }
  touchMove(event:any){
    event.screenX=event.touches[0].screenX
    event.screenY=event.touches[0].screenY
    this.pointerMove(event)
  }
  pointerMove(event:any){
    this.lastPointer=[...this.currentPointer]
    this.currentPointer=[event.screenX,event.screenY]
    const delta=[this.currentPointer[0]-this.lastPointer[0],this.currentPointer[1]-this.lastPointer[1]]
    const totalDelta=[this.currentPointer[0]-this.startPointer[0],this.currentPointer[1]-this.startPointer[1]]
    if(this.isPointerDown){
      this.controlsUpdate.next({
        case:"move",
        isPointerDown:this.isPointerDown,
        start:[...this.startPointer],
        last:[...this.lastPointer],
        current:[...this.currentPointer],
        delta,
        totalDelta,
        target:event.target,
        event
      })
    }
  }
  touchUp(event:any){
    this.pointerUp(event)
  }
  pointerUp(event:any){
    this.isPointerDown=false
    const delta=[this.currentPointer[0]-this.startPointer[0],this.currentPointer[1]-this.startPointer[1]]
    const endTime=Date.now()
    //swipes
    const deltaTime=endTime-this.startTime
    let gestures=[]
    if(deltaTime<this.timeTolerance){
      if(Math.abs(delta[0])>this.gestureTolerances[0]){
        if(delta[0]>0) gestures.push("swipe_right")
        else gestures.push("swipe_left")
      }
      if(Math.abs(delta[1])>this.gestureTolerances[1]){
        if(delta[1]>0) gestures.push("swipe_bottom")
        else gestures.push("swipe_top")
      }
      if(gestures.length>0) this.gestureUpdate.next({
        gestures,
        velocities:[Math.abs(delta[0])/deltaTime,Math.abs(delta[1])/deltaTime],
        target:event.target,
        event
      })
    }

    //all controls
    this.controlsUpdate.next({
      case:"up",
      isPointerDown:this.isPointerDown,
      start:[...this.startPointer],
      last:[...this.lastPointer],
      current:[...this.currentPointer],
      delta,
      startTime:this.startTime,
      endTime,
      gestures,
      target:event.target,
      event
    })
  }


  getControlsUpdate(){
    return this.controlsUpdate.asObservable()
  }
  getGestureUpdate(){
    return this.gestureUpdate.asObservable()
  }

  setGestureTolerance(tolX:number,tolY:number){
    this.gestureTolerances=[tolX,tolY]
  }
  setTimeTolerance(tol:number){
    this.timeTolerance=tol
  }
}
