import { Component, Input, OnInit } from '@angular/core'
import { BroadcastService } from 'src/app/services/broadcast.service'
import { environment } from 'src/environments/environment'
import { messages } from '../models/variables.enum'

@Component({
  selector: 'app-main-toolbar',
  templateUrl: './main-toolbar.component.html',
  styleUrls: ['./main-toolbar.component.scss']
})
export class MainToolbarComponent implements OnInit {

  assetsAddress:string=environment.assetsAddress+"images/"

  constructor(private bcServ:BroadcastService) { }

  @Input() title:string="EduNiBa"
  @Input() backgroundColor:string="var(--toolbar-background-color)"
  @Input() color:string="var(--toolbar-color)"
  @Input() height:string="100%"

  ngOnInit(): void {
    console.log(this.title)
  }

  toggleSidebar(name:string){
    this.bcServ.dispatch(messages.toggleSidePanel,{id:name})
  }
}
