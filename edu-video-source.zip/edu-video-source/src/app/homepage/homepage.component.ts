import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.scss']
})
export class HomepageComponent implements OnInit {
  channelEmbedAddress="https://www.youtube.com/embed?max-results=1&controls=0&showinfo=0&rel=0&listType=user_uploads&list="
  channelId:string="UCEwhtpXrg5MmwlH04ANpL8A"
  constructor() { }

  ngOnInit(): void {
  }

//   const requestOptions = {
//     method: 'GET',
//     redirect: 'follow'
// };

// const loadVideo = (iframe) => {
//     const cid = iframe.getAttribute('cid');
//     const channelURL = encodeURIComponent(`https://www.youtube.com/feeds/videos.xml?channel_id=${cid}`)
//     const reqURL = `https://api.rss2json.com/v1/api.json?rss_url=${channelURL}`;
//     fetch(reqURL, requestOptions)
//         .then(response => response.json())
//         .then(result => {
//             const videoNumber = (iframe.getAttribute('vnum') ? Number(iframe.getAttribute('vnum')) : 0);
//             const link = result.items[videoNumber].link;
//             const id = link.substr(link.indexOf("=") + 1);
//             iframe.setAttribute("src", `https://youtube.com/embed/${id}?controls=0&autoplay=1`);
//         })
//         .catch(error => console.log('error', error));
// }
// var iframes = document.getElementsByClassName('latestVideoEmbed');
// for (var i = 0, len = iframes.length; i < len; i++) {
//     loadVideo(iframes[i]);
// }

}
