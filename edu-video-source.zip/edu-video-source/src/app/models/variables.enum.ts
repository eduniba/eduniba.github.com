export enum messages{
  toggleSidePanel,
  closeSidePanel,
  openSidePanel,

  openDialog,
  closeDialog,
  confirmResponse
}

export const prewrittenDialogs={
  help:{
    type:"alert",//alert, confirm,message
    title:"Ti serve aiuto?",
    message:""
  }
}
