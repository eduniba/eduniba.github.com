import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-youtube-player',
  templateUrl: './youtube-player.component.html',
  styleUrls: ['./youtube-player.component.scss']
})
export class YoutubePlayerComponent implements OnInit {

  reframed:any
  player:any
  video:string="PL3f9YeembIXJNoc7Ehj-ZG62JwU_gKiXR"
  isRestricted:any
  constructor() { }

  ngOnInit(): void {
    this.init()
  }


  init() {
    const tag = document.createElement('script');
    tag.src = '//www.youtube.com/iframe_api';
    const firstScriptTag:any = document.getElementsByTagName('script')[0];
    (firstScriptTag.parentNode as any).insertBefore(tag, firstScriptTag);

    (window as any)['onYouTubeIframeAPIReady'] = () => this.startVideo()
  }

  startVideo() {
    this.reframed = false;
    const computed=getComputedStyle(document.getElementsByTagName("body")[0])
    let bodyW=parseFloat(computed.getPropertyValue("width"))
    let videoW=parseFloat(computed.getPropertyValue("--main-video-width"))
    if(bodyW<850) videoW=bodyW*.8
    // let sidetextW=parseFloat(computed.getPropertyValue("--text-beside-video-width"))
    // console.log(sidetextW)

    this.player = new (window as any)['YT'].Player('player', {
      // videoId: this.video,
      width:videoW,
      playerVars: {
        listType:"playlist",
        list:this.video,
        autoplay: 0,
        modestbranding: 1,
        controls: 1,
        disablekb: 1,
        rel: 0,
        showinfo: 0,
        fs: 0,
        playsinline: 1
      },
      events: {
        'onStateChange': this.onPlayerStateChange.bind(this),
        'onError': this.onPlayerError.bind(this),
        'onReady': this.onPlayerReady.bind(this),
      }
    })
  }

  onPlayerReady(event:any) {
    if (this.isRestricted) {
      event.target.mute();
    } else {
    }
  }

  onPlayerStateChange(event:any) {
    console.log(event)
    switch (event.data) {
      case (window as any)['YT'].PlayerState.PLAYING:
        if (this.cleanTime() == 0) {
          console.log('started ' + this.cleanTime());
        } else {
          console.log('playing ' + this.cleanTime())
        };
        break;
      case (window as any)['YT'].PlayerState.PAUSED:
        if (this.player.getDuration() - this.player.getCurrentTime() != 0) {
          console.log('paused' + ' @ ' + this.cleanTime());
        };
        break;
      case (window as any)['YT'].PlayerState.ENDED:
        console.log('ended ');
        break;
    }
  }

  cleanTime() {
    return Math.round(this.player.getCurrentTime())
  }

  onPlayerError(event:any) {
    switch (event.data) {
      case 2:
        console.log('' + this.video)
        break;
      case 100:
        break;
      case 101 || 150:
        break;
    }
  }

}
