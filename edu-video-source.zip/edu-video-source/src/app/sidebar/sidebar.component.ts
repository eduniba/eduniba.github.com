import { Component, OnInit, ViewChild } from '@angular/core'
import { messages, prewrittenDialogs } from 'src/app/models/variables.enum'
import { BroadcastService } from 'src/app/services/broadcast.service'
import { SidePanelComponent } from 'src/app/reusables/side-panel/side-panel.component'

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {

  id:string="side-panel"

  @ViewChild("panel") panel:SidePanelComponent|undefined


  constructor(
    private bcServ:BroadcastService) { }

  ngOnInit(): void {
    this.bcServ.getEventBroadcaster().subscribe((message)=>this.respond(message))
  }

  respond(message:any){
    switch(message.name){
      case messages.toggleSidePanel:
        if(message.detail.id==this.id&&!this.panel?.showing){
          // this.getUserYear()
        }
        break
      case messages.confirmResponse:
        // if(message.detail.value&&message.detail.passOn===this.codiceConferma) this.recordServ.deleteUserYear()
        break
      default:break
    }
  }

  callHelp(){
    this.bcServ.dispatch(messages.openDialog,prewrittenDialogs.help)
  }
}
